<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>Olá meus adms disponível no momento são\n @PabloEscobarOfc</b>",
	'parse_mode' => 'html'
]);