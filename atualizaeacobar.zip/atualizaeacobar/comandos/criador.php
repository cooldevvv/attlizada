<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>📜 · @NorthSms_bot \n\n ▫️ · SUPORTE: @PabloEscobarOfc</b>",
	'parse_mode' => 'html'
]);