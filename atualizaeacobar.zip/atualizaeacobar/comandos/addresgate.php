<?php

if (in_array ($tlg->UserID (), ADMS)){

	$valor = $complemento;

	if (!is_numeric ($valor)){

		$tlg->sendMessage ([
			'chat_id' => $tlg->ChatID (),
			'text' => "Siga o exemplo <code>/addresgate 10</code>",
			'parse_mode' => 'html'
		]);

	}else {

		$codigo = 'gift-northsms-'.gerarHash (4).'-bot-'.gerarHash (3);

		$bd_tlg->addCodigoResgate ($codigo, $valor);
                
		$tlg->sendMessage ([
			'chat_id' => $tlg->ChatID (),
			'text' => "🏅 - GIFT GERADO\n\n 🎫 · <code>{$codigo}</code>\n💸 · Valor: <b>R\$ {$valor}</b> ✅\n\nResgate: <code>/resgatar {$codigo}</code>",
			'parse_mode' => 'html'
		]);

	}

}