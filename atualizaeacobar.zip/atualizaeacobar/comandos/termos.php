<?php

if ($tlg->Callback_ID () !== null){
	
	// encerra carregamento do botão de callback
	$tlg->answerCallbackQuery ([
		'callback_query_id' => $tlg->Callback_ID ()
	]);

}
$id_pagamento = $pagamento ['id'];
$bonus = (BONUS == 0) ? '' : '<em><u>+'.BONUS.'% bônus</u></em>';
$valor_pagamento = 11;

if (isset ($complemento)){

	// pega valor e tipo de calculo
	@list ($valor, $calculo) = explode (' ', $complemento);

	switch ($calculo) {
		case "+1":

		$valor_pagamento = ++$valor;

			break;

		case "+10":

		$valor_pagamento = $valor+10;

			break;

		case "-10":

		$valor_pagamento = $valor-10;

			break;
		
		case "-1":

			case "-50":

				$valor_pagamento = $valor-50;
		
					break;
					case "+50":

						$valor_pagamento = $valor+50;
				
							break;

		$valor_pagamento = --$valor;

			break;
	}

	// checagem de valor abaixo do mínimo
	if ($valor_pagamento < 11){
		$valor_pagamento = 11;
	}

}

$dados_mensagem = [
	'chat_id' => $tlg->ChatID (),
	'text' => "😃 Para que serve esse bot?
No nosso serviço você tem a capacidade de receber SMS de números virtuais temporários.
Casos de uso:
Crie contas verificadas por telefone sem precisar usar o seu número real, proteja-se de sites fraudulentos que precisam inserir seu número para baixar arquivos ou usar um serviço, correndo risco de obter serviços pagos e assinatura inserindo o seu número real; Impeça spam de SMS usando nosso números descartaveis.

🎈Como receber sms pelo bot?
Use o comando /servicos e veja os serviços disponíveis para receber sms.

🎈Como colocar saldo na minha conta?
Use o comando /recarregar escolha o valor, após o pagamento o saldo é adicionado automaticamente na sua conta.

🎈 Posso ficar com o número após o uso?
Não, os números são descartaveis/temporarios, após o uso eles são substituidos por novos, servindo somente para confirmação ou criação de cadastros.

🎈Como resgatar meu saldo comprado?
O saldo é adicionado automaticamente na sua conta, caso isso não aconteça entre em contato com @PabloEscobarOfc

🎈Não tem números disponíveis!
Use o comando /alertas, você será notificado quando novos números estiverem disponíveis para o serviço escolhido.

🎈O SMS não chegou?
Caso o SMS não chegue no número siga as /dica do bot para um bom uso, você também pode cancelar o número e pedir outro desde que não tenha abuso de cancelamento.
Se preferir você também pode deixar o número e pedir outro.
Não se preocupe o número só é cobrado quando chegar o SMS exceto em algumas ocasiões de abuso.

🎈Quais os limites de uso?
Existem limites de cancelamentos e de números que você pode ter ativos simultâneamente no bot, após uma quantidade anormal de números ativos em um curto periodo de tempo os proximos números nesse curto periodo serão cobrados mesmo se não houver o uso e não haverá reembolso.


⚠️ Termos de uso:
Em caso de quaisquer tipo de abusos no uso do bot você pode ser penalizado com bloqueio ou redução no seu saldo atual, esses termos entram em vigor apartir do momento em que você iniciou o bot.
É proibida autilização do serviço para quaisquer fins ilegais, bem como não realizar uso para ações que prejudiquem o serviço ou terceiros, também é proibido o uso do serviço para assinaturas pagas.
Devoluções Não são permitadas apartir do momento que voce confirma o pagamento voce concorda com os nossos termos.

,
	'parse_mode' => 'html',
	'message_id' => $tlg->MessageID (),
	'disable_web_page_preview' => 'true',
	'reply_markup' => $tlg->buildInlineKeyboard ([
		[
			$tlg->buildInlineKeyBoardButton ("✔️Aceito✔️", null, "/start"),
                        $tlg->buildInlineKeyBoardButton ("❌Nao aceito❌", null, "/ajuda")
                 ],
	])
];

if ($tlg->Callback_ID () !== null){

	$tlg->editMessageText ($dados_mensagem);

}else {

	$tlg->sendMessage ($dados_mensagem);

}