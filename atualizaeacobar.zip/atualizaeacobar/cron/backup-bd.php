<?php

include __DIR__.'/../includes/includes.php';

$tlg = new Telegram ('519568936:AAGn495DHqKoLusyyBhzI7yMi4ggMslLUjo');

print_r ($tlg->sendDocument ([
	'chat_id' => @itachisms2,
	'caption' => "Backup\n@itachisms2\n".date ('d/m/Y H:i:s'),
	'document' => curl_file_create (__DIR__.'/../recebersmsbot.db')
]));